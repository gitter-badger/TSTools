class TSLengthException(Exception):
    """ Exception stating timeseries does not contain enough observations
    """
    pass
