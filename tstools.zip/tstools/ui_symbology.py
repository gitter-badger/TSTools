# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/ui_symbology.ui'
#
# Created: Tue Sep 16 19:05:39 2014
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Symbology(object):
    def setupUi(self, Symbology):
        Symbology.setObjectName(_fromUtf8("Symbology"))
        Symbology.resize(640, 320)
        self.verticalLayout = QtGui.QVBoxLayout(Symbology)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.widget = QtGui.QWidget(Symbology)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.gridLayout = QtGui.QGridLayout(self.widget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.widget_sym = QtGui.QWidget(self.widget)
        self.widget_sym.setObjectName(_fromUtf8("widget_sym"))
        self.gridLayout_3 = QtGui.QGridLayout(self.widget_sym)
        self.gridLayout_3.setMargin(0)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.stack_widget = QtGui.QStackedWidget(self.widget_sym)
        self.stack_widget.setObjectName(_fromUtf8("stack_widget"))
        self.page = QtGui.QWidget()
        self.page.setObjectName(_fromUtf8("page"))
        self.stack_widget.addWidget(self.page)
        self.page_2 = QtGui.QWidget()
        self.page_2.setObjectName(_fromUtf8("page_2"))
        self.stack_widget.addWidget(self.page_2)
        self.gridLayout_3.addWidget(self.stack_widget, 1, 0, 1, 1)
        self.label_2 = QtGui.QLabel(self.widget_sym)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_3.addWidget(self.label_2, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.widget_sym, 0, 1, 1, 1)
        self.widget_2 = QtGui.QWidget(self.widget)
        self.widget_2.setMaximumSize(QtCore.QSize(200, 16777215))
        self.widget_2.setObjectName(_fromUtf8("widget_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.widget_2)
        self.gridLayout_2.setMargin(0)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.list_metadata = QtGui.QListWidget(self.widget_2)
        self.list_metadata.setObjectName(_fromUtf8("list_metadata"))
        self.gridLayout_2.addWidget(self.list_metadata, 1, 0, 1, 1)
        self.but_load_metadata = QtGui.QPushButton(self.widget_2)
        self.but_load_metadata.setStyleSheet(_fromUtf8(""))
        self.but_load_metadata.setObjectName(_fromUtf8("but_load_metadata"))
        self.gridLayout_2.addWidget(self.but_load_metadata, 2, 0, 1, 1)
        self.label = QtGui.QLabel(self.widget_2)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.widget_2, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.widget)
        self.button_box = QtGui.QDialogButtonBox(Symbology)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Apply|QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName(_fromUtf8("button_box"))
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(Symbology)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("accepted()")), Symbology.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("rejected()")), Symbology.reject)
        QtCore.QMetaObject.connectSlotsByName(Symbology)

    def retranslateUi(self, Symbology):
        Symbology.setWindowTitle(_translate("Symbology", "Dialog", None))
        self.label_2.setText(_translate("Symbology", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600;\">Metadata Symbology</span></p></body></html>", None))
        self.but_load_metadata.setText(_translate("Symbology", "Attach Metadata", None))
        self.label.setText(_translate("Symbology", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600;\">Available Metadata</span></p></body></html>", None))

