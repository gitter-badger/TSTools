# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/ui_symbology.ui'
#
# Created: Mon Jul  7 18:32:48 2014
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Symbology(object):
    def setupUi(self, Symbology):
        Symbology.setObjectName(_fromUtf8("Symbology"))
        Symbology.resize(640, 480)
        self.verticalLayout = QtGui.QVBoxLayout(Symbology)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.widget = QtGui.QWidget(Symbology)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.gridLayout = QtGui.QGridLayout(self.widget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.widget_2 = QtGui.QWidget(self.widget)
        self.widget_2.setMaximumSize(QtCore.QSize(200, 16777215))
        self.widget_2.setObjectName(_fromUtf8("widget_2"))
        self.gridLayout_2 = QtGui.QGridLayout(self.widget_2)
        self.gridLayout_2.setMargin(0)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.but_load_metadata = QtGui.QPushButton(self.widget_2)
        self.but_load_metadata.setObjectName(_fromUtf8("but_load_metadata"))
        self.gridLayout_2.addWidget(self.but_load_metadata, 1, 0, 1, 1)
        self.list_metadata = QtGui.QListWidget(self.widget_2)
        self.list_metadata.setObjectName(_fromUtf8("list_metadata"))
        self.gridLayout_2.addWidget(self.list_metadata, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.widget_2, 0, 0, 1, 1)
        self.widget_3 = QtGui.QWidget(self.widget)
        self.widget_3.setObjectName(_fromUtf8("widget_3"))
        self.gridLayout_3 = QtGui.QGridLayout(self.widget_3)
        self.gridLayout_3.setMargin(0)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.table_symbol = QtGui.QTableWidget(self.widget_3)
        self.table_symbol.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.table_symbol.setColumnCount(3)
        self.table_symbol.setObjectName(_fromUtf8("table_symbol"))
        self.table_symbol.setRowCount(0)
        item = QtGui.QTableWidgetItem()
        self.table_symbol.setHorizontalHeaderItem(0, item)
        item = QtGui.QTableWidgetItem()
        self.table_symbol.setHorizontalHeaderItem(1, item)
        item = QtGui.QTableWidgetItem()
        self.table_symbol.setHorizontalHeaderItem(2, item)
        self.table_symbol.horizontalHeader().setStretchLastSection(True)
        self.table_symbol.verticalHeader().setStretchLastSection(False)
        self.gridLayout_3.addWidget(self.table_symbol, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.widget_3, 0, 1, 1, 1)
        self.verticalLayout.addWidget(self.widget)
        self.buttonBox = QtGui.QDialogButtonBox(Symbology)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Apply|QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Symbology)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), Symbology.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Symbology.reject)
        QtCore.QMetaObject.connectSlotsByName(Symbology)

    def retranslateUi(self, Symbology):
        Symbology.setWindowTitle(_translate("Symbology", "Dialog", None))
        self.but_load_metadata.setText(_translate("Symbology", "Load", None))
        item = self.table_symbol.horizontalHeaderItem(0)
        item.setText(_translate("Symbology", "Value", None))
        item = self.table_symbol.horizontalHeaderItem(1)
        item.setText(_translate("Symbology", "Symbol", None))
        item = self.table_symbol.horizontalHeaderItem(2)
        item.setText(_translate("Symbology", "Color", None))

